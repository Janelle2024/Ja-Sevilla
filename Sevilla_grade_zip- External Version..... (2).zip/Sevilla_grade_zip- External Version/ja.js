function computeGrade() {
    const midtermGrade = parseFloat(document.getElementById('midtermGrade').value);
    const finalGrade = parseFloat(document.getElementById('finalGrade').value);
    
    if (isNaN(midtermGrade) || isNaN(finalGrade)) {
        alert("Please enter valid grades for both fields!");
        return;
    }

    const finalGradeResult = (midtermGrade + finalGrade) / 2;
    document.getElementById('finalGradeResult').innerText = finalGradeResult.toFixed(2);

    let remarks;
    if (finalGradeResult >= 99) {
        remarks = '1.0';
    } else if (finalGradeResult >= 97) {
        remarks = '1.1';
    } else if (finalGradeResult >= 96) {
        remarks = '1.2';
    } else if (finalGradeResult >= 94) {
        remarks = '1.3';
    } else if (finalGradeResult >= 93) {
        remarks = '1.5';
    } else if (finalGradeResult >= 90) {
        remarks = '1.6';
    } else if (finalGradeResult >= 89) {
        remarks = '1.8';
    } else if (finalGradeResult >= 75) {
        remarks = '3.0';
    } else {
        remarks = '5.0';
    }

    document.getElementById('remarksResult').innerText = remarks;
}

function resetForm() {
    document.getElementById('gradeForm').reset();
    document.getElementById('finalGradeResult').innerText = '';
    document.getElementById('remarksResult').innerText = '';
}